import { useEffect } from "react";
import { useForm } from "react-hook-form";
import type { KnowledgeCard, KnowledgeCardInput } from "../types/knowledge";
import { Button } from "./Button";

const empty: KnowledgeCardInput = {
  code: "",
  title: "",
  category: "",
  status: "draft",
  version: "1.0.0",
  summary: "",
  symptoms: "",
  causes: "",
  diagnosis: "",
  procedure: "",
  tools: "",
  safety: ""
};

type Props = {
  card?: KnowledgeCard | null;
  onCancel: () => void;
  onSave: (values: KnowledgeCardInput) => Promise<void>;
};

export function KnowledgeEditor({ card, onCancel, onSave }: Props) {
  const { register, handleSubmit, reset, formState } =
    useForm<KnowledgeCardInput>({ defaultValues: empty });

  useEffect(() => {
    reset(card ? {
      code: card.code,
      title: card.title,
      category: card.category,
      status: card.status,
      version: card.version,
      summary: card.summary,
      symptoms: card.symptoms,
      causes: card.causes,
      diagnosis: card.diagnosis,
      procedure: card.procedure,
      tools: card.tools,
      safety: card.safety
    } : empty);
  }, [card, reset]);

  return (
    <form className="editor-card" onSubmit={handleSubmit(onSave)}>
      <header>
        <div>
          <p className="eyebrow">KNOWLEDGE EDITOR</p>
          <h2>{card ? "Modifica Knowledge Card" : "Nuova Knowledge Card"}</h2>
        </div>
        <div className="editor-actions">
          <Button type="button" className="button-secondary" onClick={onCancel}>
            Annulla
          </Button>
          <Button type="submit" disabled={formState.isSubmitting}>
            {formState.isSubmitting ? "Salvataggio..." : "Salva"}
          </Button>
        </div>
      </header>

      <div className="form-grid">
        <label>Codice<input {...register("code", { required: true })} disabled={!!card} /></label>
        <label>Titolo<input {...register("title", { required: true })} /></label>
        <label>Categoria<input {...register("category", { required: true })} /></label>
        <label>Stato<select {...register("status")}><option value="draft">Bozza</option><option value="review">In revisione</option><option value="published">Pubblicata</option></select></label>
        <label>Versione<input {...register("version")} /></label>
      </div>

      <div className="editor-tabs">
        <label>Riassunto<textarea {...register("summary")} /></label>
        <label>Sintomi<textarea {...register("symptoms")} /></label>
        <label>Cause<textarea {...register("causes")} /></label>
        <label>Diagnosi<textarea {...register("diagnosis")} /></label>
        <label>Procedura<textarea {...register("procedure")} /></label>
        <label>Strumenti<textarea {...register("tools")} /></label>
        <label>Sicurezza<textarea {...register("safety")} /></label>
      </div>
    </form>
  );
}
